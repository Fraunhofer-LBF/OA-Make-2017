"""
Try to embed the RD estimation and plotting int PyQT4

"""
import sys

import matplotlib
matplotlib.use('Qt5Agg')
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from PyQt5.QtWidgets import (QSlider, QPushButton, QCheckBox, QRadioButton, 
                             QSpinBox, QGroupBox, QHBoxLayout, QGridLayout, 
                             QLineEdit, QMainWindow, QAction, qApp, 
                             QApplication, QMessageBox, QLabel, QVBoxLayout, 
                             QFileDialog, QWidget)
from PyQt5.QtGui import QIcon  
from PyQt5.QtCore import Qt, QRect

import soundcard as rs
import scipy as sp
import numpy as np
import bilinear

from scipy.signal import lfilter

import rd_estim
import decimate_filter

""" Set some global parameters"""
frame_size = 1024*30
pre_time = 0.2

cutoff_soundcard = 100.0*2*np.pi
cutoff_compensation = 10.0*2*np.pi
cutoff_highpass = 5.0*2*np.pi

RD_order = 256*2
trigger_level = 0.01
mirror = 1;
trigger_condition = 3;

global counter
counter = 1.0;

raw_data = []
#global RD_sequence
RD_sequence = np.zeros(RD_order)

class AppForm(QMainWindow):
    def __init__(self, parent=None):
        QMainWindow.__init__(self, parent)
        self.setWindowTitle('RD Autocorrelation Estimator')

        self.create_menu()
        self.create_main_frame()
        self.create_status_bar()

        self.textbox.setText('512')
        self.textbox2.setText('2')
        self.spinBox_2.setValue(8000)
        self.spinBox.setValue(4)

    def save_plot(self):
        file_choices = "PNG (*.png)|*.png"
        
        path = (QFileDialog.getSaveFileName(self, 
                        'Save file', '', 
                        file_choices))
        if path:
            self.canvas.print_figure(path, dpi=self.dpi)
            self.statusBar().showMessage('Saved to %s' % path, 2000)
            
    def level_crossing(self):
        self.trigger_condition = 1;
        self.statusBar().showMessage('Level Crossing Trigger')
        
    def local_extremum(self):
        self.trigger_condition = 2;
        self.statusBar().showMessage('Local Extremum Trigger')
               
    def positive_point(self):
        self.trigger_condition = 3;
        self.statusBar().showMessage('Positive Point Trigger')
        
   
    def on_draw(self):
         """ Redraws the figure
         """
         global RD_sequence
         global counter
         
         rate_in = self.spinBox_2.value()
         
         str = self.textbox.text()
         RD_order = int(str)
         
         str = self.textbox2.text()
         
         pre_samples = int(pre_time*rate_in)
         frame_size = int(str)*rate_in + pre_samples
         
         dec_factor = self.spinBox.value()
         
         rate_down = rate_in/dec_factor
         
         """ design the compensation filter"""
         num_compensation_s = [1.0, cutoff_soundcard]
         den_compensation_s = [1.0, cutoff_compensation]

         [num_compensation, den_compensation] = \
         bilinear.bilinear(num_compensation_s,den_compensation_s,rate_in)
         
         """ design a highpass filter"""
 
         num_highpass_s = [1.0, 0]
         den_highpass_s = [1.0, cutoff_highpass]

         [num_highpass, den_highpass] = \
         bilinear.bilinear(num_highpass_s,den_highpass_s,rate_in)

         RD_sequence = np.zeros(RD_order)
         RD_time = np.arange(0,RD_order)
         RD_freq = np.linspace(0,rate_down/2,RD_order/2)
         
         trigger_level = self.slider.value() / 100.0

         self.statusBar().showMessage('Recording')
        
         raw_data = rs.read_from_soundcard(frame_size, rate_in) 
         raw_data = (raw_data[pre_samples:])
         raw_time = np.arange(0,float(len(raw_data))/rate_in,1.0/rate_in)
   
   
         if self.checkbox.isChecked():
            """ kill an offset"""
            compensated_data = lfilter(num_highpass,den_highpass,raw_data)   
         else:
            compensated_data = raw_data;
                 
        
         """ compensate the high pass characteristics """
         compensated_data = lfilter(num_compensation,den_compensation,compensated_data)
         
         if dec_factor != 1:
            """ Downsampling"""
            decimated_data = decimate_filter.decimate_filter(compensated_data, dec_factor)
         else:
            decimated_data = compensated_data
       
         data_time = np.arange(0,float(len(decimated_data))/rate_down,1.0/rate_down)
         
         self.statusBar().showMessage('RD Estimation')
        
         """ Estimate the RD signature"""
         
         [RD_sequence, counter_out, trigger_event_time, trigger_event_amp] = \
         rd_estim.RD_frame(decimated_data, trigger_level, mirror, trigger_condition,\
             RD_order, counter, RD_sequence)
                      
         """ Calculate spectrum"""
         RD_spectrum = sp.fft(RD_sequence)
         RD_spectrum = RD_spectrum[0:RD_order/2]
         
         self.axes1.hold()
         self.axes1.plot(raw_time, compensated_data, 'r:')
         self.axes1.hold()
         self.axes1.plot(data_time, decimated_data)
         if counter_out > 1:
            self.axes1.plot(trigger_event_time/rate_down,trigger_event_amp,'ro')
         self.axes1.set_ylabel('Input')
         self.axes1.set_xlabel('Time [samples]')
         self.axes1.set_title('Trigger Events %i' %counter_out)
         self.axes2.hold()
         self.axes2.plot(RD_time, RD_sequence)
         self.axes2.set_ylabel('D_xx')
         self.axes2.set_xlabel('N')
         self.axes2.hold()
         self.axes3.hold()
         self.axes3.plot(RD_freq,abs(RD_spectrum))
         self.axes3.set_ylabel('Autopower')
         self.axes3.set_xlabel('frequency [Hz]')
         self.axes3.hold()
         
         self.statusBar().showMessage('Ready')
        
         self.canvas.draw()
    
    def create_main_frame(self):
        self.main_frame = QWidget()
        
        # Create the mpl Figure and FigCanvas objects. 
        # 5x4 inches, 100 dots-per-inch
        #
        self.dpi = 100
        self.fig = Figure((5.0, 4.0), dpi=self.dpi)
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setParent(self.main_frame)
        
        self.axes1 = self.fig.add_subplot(3,1,1)
        self.axes2 = self.fig.add_subplot(3,1,2)
        self.axes3 = self.fig.add_subplot(3,1,3)
        
        self.axes2.hold('False')
        self.axes3.hold('False')
        
       
        # Create the navigation toolbar, tied to the canvas
                
        # Other GUI controls
        # 
        textbox_label = QLabel('RD order:')
        self.textbox = QLineEdit()
        self.textbox.setMinimumWidth(0.5)
        
        textbox2_label = QLabel('Record length [s]:')
        self.textbox2 = QLineEdit()
        self.textbox2.setMinimumWidth(0.5)
           
        spinBox_label = QLabel('Decimation')
        self.spinBox = QSpinBox()
        self.spinBox.setGeometry(QRect(440, 260, 71, 22))
        self.spinBox.setMinimum(1)
        self.spinBox.setMaximum(10)
        self.spinBox.setSingleStep(1)
        self.spinBox.setObjectName("spinBox")
        
        spinBox_2_label = QLabel('Sampling Frequency [Hz]')
        self.spinBox_2 = QSpinBox()
        self.spinBox_2.setGeometry(QRect(440, 260, 71, 22))
        self.spinBox_2.setMinimum(4000)
        self.spinBox_2.setMaximum(8000)
        self.spinBox_2.setSingleStep(4000)
        self.spinBox_2.setObjectName("spinBox_2")
        
        self.draw_button = QPushButton("&GO!")
        self.draw_button.clicked.connect(self.on_draw)
        
        slider_label = QLabel('Trigger Level (%):')
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(1, 100)
        self.slider.setValue(25)
        self.slider.setTracking(True)
        self.slider.setTickPosition(QSlider.TicksBothSides)
        self.slider.setMinimumWidth(0.8)
        
        checkbox_label = QLabel('Highpass')
        self.checkbox = QCheckBox()
        self.checkbox.toggle()
        
        self.buttonGroup = QGroupBox('Trigger Condition')
        hLayout = QVBoxLayout()
        self.buttonGroup.setLayout(hLayout)
        self.radio1 = QRadioButton("Level Crossing", self.buttonGroup)
        self.radio2 = QRadioButton("Local Extremum", self.buttonGroup)
        self.radio3 = QRadioButton("Positive Point", self.buttonGroup)
        hLayout.addWidget(self.radio1)
        hLayout.addWidget(self.radio2)
        hLayout.addWidget(self.radio3)

        self.radio1.setChecked(1)    
        
        #
        # Layout with box sizers
        # 
        
        control_box = QHBoxLayout()
        
        grid_box = QGridLayout()
        
        grid_box.addWidget(textbox_label,0,5)
        grid_box.addWidget(self.textbox,1,5)
        
        grid_box.addWidget(textbox2_label,0,2)
        grid_box.addWidget(self.textbox2,1,2)
        
        grid_box.addWidget(slider_label,0,4)
        grid_box.addWidget(self.slider,1,4)
        
        grid_box.addWidget(spinBox_label,0,3)
        grid_box.addWidget(self.spinBox,1,3)
        
        grid_box.addWidget(spinBox_2_label,0,0)
        grid_box.addWidget(self.spinBox_2,1,0)
        
        grid_box.addWidget(checkbox_label,0,1)
        grid_box.addWidget(self.checkbox,1,1)
        
        control_box.addLayout(grid_box)
 
        control_box.addWidget(self.draw_button)
        
        vbox = QVBoxLayout()
        vbox.addWidget(self.canvas)
  
        vbox.addLayout(control_box)
               
        self.main_frame.setLayout(vbox)
        self.setCentralWidget(self.main_frame)
    
    def create_status_bar(self):
        
        self.statusBar().showMessage('RD Autocorrelation Estimator')
        
    def create_menu(self):    

        
        ''' Exit '''
        exitAction = QAction(QIcon('exit.png'), '&Exit', self)        
        exitAction.setShortcut('Ctrl+Q')
        exitAction.setStatusTip('Exit application')
        exitAction.triggered.connect(qApp.quit)
      
        SaveFileAction = QAction(QIcon('filesave.png'), '&Save plot', self)
        SaveFileAction.setShortcut('Ctrl+S')  
        SaveFileAction.setStatusTip('Save the plot')
        SaveFileAction.triggered.connect(self.save_plot)
 
        TriggerLevelCrossingAction = QAction('&Level Crossing', self)
        TriggerLevelCrossingAction.setStatusTip('Set Trigger to Level Crossing')
        TriggerLevelCrossingAction.triggered.connect(self.level_crossing)
        
        TriggerLocalExtremumAction = QAction('&Local Extremum', self)
        TriggerLocalExtremumAction.setStatusTip('Set Trigger to Local Extremum')
        TriggerLocalExtremumAction.triggered.connect(self.local_extremum)
        
        TriggerPositivePointAction = QAction('&PositivePoint', self)
        TriggerPositivePointAction.setStatusTip('Set Trigger to Positive Point')
        TriggerPositivePointAction.triggered.connect(self.positive_point)
                
        menubar = self.menuBar()
        
        self.fileMenu = menubar.addMenu('&File')
        self.fileMenu.addAction(exitAction)
        self.fileMenu.addAction(SaveFileAction)  
        
        self.triggerMenu = menubar.addMenu("&Trigger")
        self.triggerMenu.addAction(TriggerLevelCrossingAction)
        self.triggerMenu.addAction(TriggerLocalExtremumAction)
        self.triggerMenu.addAction(TriggerPositivePointAction)


def main():
    app = QApplication(sys.argv)
    form = AppForm()
    form.show()
    app.exec_()


if __name__ == "__main__":
    main()
