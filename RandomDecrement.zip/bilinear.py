import scipy as sp
import numpy as np
from scipy.misc import comb

def bilinear(b,a,fs=1.0):
    """Return a digital filter from an analog filter using the bilinear transform.

    The bilinear transform substitutes (z-1) / (z+1) for s
    """    
    """a,b = map(r1array,(a,b))"""
    D = len(a) - 1
    N = len(b) - 1
    M = max([N,D])
    Np = M
    Dp = M
    bprime = np.zeros(Np+1)
    aprime = np.zeros(Dp+1)
    for j in range(Np+1):
        val = 0.0
        for i in range(N+1):
             for k in range(i+1):
                for l in range(M-i+1):
                    if k+l == j:
                        val += comb(i,k)*comb(M-i,l)*b[N-i]*pow(2*fs,i)*(-1)**k
        bprime[j] = val
    for j in range(Dp+1):
        val = 0.0
        for i in range(D+1):
            for k in range(i+1):
                for l in range(M-i+1):
                    if k+l == j:
                        val += comb(i,k)*comb(M-i,l)*a[D-i]*pow(2*fs,i)*(-1)**k
        aprime[j] = val
        
    return (bprime, aprime)
