import pyaudio
import numpy as np

def read_from_soundcard(chunk, RATE):

    """ Read data from soundcard"""
    """ Input: chunk = batch size"""
    """        RATE  = Sampling rate"""

    FORMAT = pyaudio.paInt16
    CHANNELS = 2
    RECORD_SECONDS = 1

    p = pyaudio.PyAudio()

    stream = p.open(format=FORMAT,
                channels=CHANNELS,
                rate=RATE,
                input=True,
                frames_per_buffer=chunk)

    print("* recording")

    raw_data_string = stream.read(chunk)

    raw_data = np.fromstring(raw_data_string,dtype=np.int16)
    raw_data = np.trim_zeros(raw_data,'f')
    raw_data = (raw_data[2000:])/(2.0**16)

    return raw_data




